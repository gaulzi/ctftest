# ~/.bashrc
export PS1='\u@\h:\w\$ '
alias ll='ls -alF'
alias metar='curl -s https://aviationweather.gov/api/data/metar?ids=EBBR'
