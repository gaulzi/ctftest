#!/bin/sh
# deploy script
API_TOKEN="$DEPLOY_TOKEN"   # moved to env var
curl -H "Authorization: $API_TOKEN" https://ops.hostbusters.local/deploy
